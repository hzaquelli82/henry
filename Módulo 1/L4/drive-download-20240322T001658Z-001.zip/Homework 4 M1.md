![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

## Homework

Repasá la tarea descrita en los archivos
  * Homework_04_1.ipynb
  * Homework_04_2.ipynb
  * Homework_04_3.ipynb

### Homework 4_4

A partir del CSV hospitales2.csv, generar un archivo CSV de salida, que contenga los siguientes campos en este orden:<br>
latitude<br>
longitude<br>
name<br>
label<br>
Con los correspondientes datos extraídos del CSV original, el campo name tiene que corresponder con la dirección del hospital, y el campo label con el nombre del hospital.<br>
Ejemplo de visualización en: https://www.gpsvisualizer.com

## Recursos adicionales

* [Ciento uno ejercicios de Pandas] (https://github.com/rougier/numpy-100)
https://www.machinelearningplus.com/python/101-pandas-exercises-python/)
